using System;
using System.Collections.Generic;
using System.Text;

namespace MarkHeath.MidiUtils
{
    enum OutputMidiType
    {
        LeaveUnchanged,
        Type0,
        Type1
    }
}
